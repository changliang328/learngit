package com.btlfinger.fingerprintunlock;
import com.btlfinger.fingerprint.FingerPrintManager;
/**
 * 
 * @author blestech
 * @since 2015-11-26
 */
public class PackagesConstant {
	public static String SETTINGS_NEEDLOCK_APP_PACKAGENAMES = FingerPrintManager.SETTINGS_NEEDLOCK_APP_PACKAGENAMES;
	public static String SETTINGS_LAST_LOCK_APP_PACKAGENAME = FingerPrintManager.SETTINGS_LAST_LOCK_APP_PACKAGENAME;
	public static String SETTINGS_INITIALIZE_PWD = FingerPrintManager.SETTINGS_INITIALIZE_PWD;
    public static String FINGERPRINTUNLCOK_PACKAGENAME = "com.btlfinger.fingerprintunlock";
}
