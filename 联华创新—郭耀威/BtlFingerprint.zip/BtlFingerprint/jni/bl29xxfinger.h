int User_WaitScreenOn();
int User_IsFingerUp();
int User_PowerDown();
int User_GetId(int *outbuffer);
int User_WriteKeycode(int keycode);
