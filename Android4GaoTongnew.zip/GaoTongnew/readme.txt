
4.4�����ֲ�ο�:

��ֲ�������:
packages/apps/Settings/res/xml/dashboard_categories.xml
��ͨ�����ж�Ӧ�޸�:
packages/apps/Settings/res/xml/settings_headers.xml
+    <header
+                android:id="@+id/fingerscanner_settings"
+                android:title="@string/unlock_set_finger_print_title"                
+                android:icon="@drawable/ic_settings_finger_scanner" >
+                <intent
+                  android:targetClass="com.btlfinger.fingerprintunlock.ui.support.ManageFp
+                  android:targetPackage="com.btlfinger.fingerprintunlock" />       
+    </header>




frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarKeyguardViewManager.java:537: ����: �Ҳ�������
        mPhoneStatusBar.updateFpStatusLabel(intent);
                       ^
  ����:   ���� updateFpStatusLabel(Intent)
  λ��: ����ΪPhoneStatusBar�ı��� mPhoneStatusBar
frameworks/base/packages/SystemUI/src/com/android/systemui/statusbar/phone/StatusBarKeyguardViewManager.java:541: ����: �Ҳ�������
        mPhoneStatusBar.updateFpActiveStatus(status);
                       ^
  ����:   ���� updateFpActiveStatus(int)
  λ��: ����ΪPhoneStatusBar�ı��� mPhoneStatusBar


�޸�Ϊ:
 public void updateFpStatus(Intent intent) {
       // mPhoneStatusBar.updateFpStatusLabel(intent);
        mPhoneStatusBar.updateFingerprintStatus(intent);
    }

    public void updateFpActiveStatus(int status) {
       // mPhoneStatusBar.updateFpActiveStatus(status);
    }





��д���
adb reboot bootloader
sudo fastboot flash boot out/target/product/msm8916_32/boot.img
sudo fastboot reboot

���ͣ�

out/target/product/msm8916_32/system/priv-app/BtlFingerprint.apk
out/target/product/msm8916_32/system/lib/libbtlfp.so
out/target/product/msm8916_32/system/lib/libBtlAlgo.so
out/target/product/msm8916_32/system/lib/libBtlFpHal.so


out/target/product/msm8916_32/system/framework/framework2.jar
out/target/product/msm8916_32/system/framework/framework.jar
out/target/product/msm8916_32/system/framework/services.jar
out/target/product/msm8916_32/system/framework/android.policy.jar
out/target/product/msm8916_32/system/priv-app/Keyguard.apk
out/target/product/msm8916_32/system/priv-app/SystemUI.apk
out/target/product/msm8916_32/data/app/SystemUITests.apk

ɾ����
rm -rf /data/dalvik-cache/system@priv-app@SystemUI.apk@classes.dex
